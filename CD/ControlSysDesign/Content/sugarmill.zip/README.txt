In the included M-file is the system model for the sugar mill problem
  in state space form (i.e. it contains A,B,C,D matrices for the system 
  model).

There are two outputs :

  y(t) = | tau(t) |
         |  h(t)  |

And three inputs:

  u(t) = |  f(t)  |
         |  w(t)  |
         |  d(t)  |


