% In this M-file is the system model for the sugar mill problem
%   in state space form (i.e. it contains A,B,C,D matrices for
%   the system model).
%
% There are two outputs :
%
%   y(t) = | tau(t) |
%          |  h(t)  |
%
% And three inputs:
%
%   u(t) = |  f(t)  |
%          |  w(t)  |
%          |  d(t)  |
%


A = [
   -0.0400         0         0         0         0;
         0   -1.0000         0         0         0;
         0         0         0         0         0;
         0         0         0   -0.0400         0;
         0         0         0         0         0; ];
B = [
     1     0     0;
     0     1     0;
     0     1     1;
     1     0     0;
     0     1     1; ];
C = [
   -0.2000   -1.0000   -0.0050         0         0;
         0         0         0    0.0400   -0.0023; ];
D = [
     0     1     0;
     0     0     0; ];

